//var vemeaddr = "0xB9645B924D4b304066D6bae01df76Ff13E592985";
var vemeaddr = "0xD48c2203c2141f1AF41fe87B904c1F47eBf35438";
export {vemeaddr}