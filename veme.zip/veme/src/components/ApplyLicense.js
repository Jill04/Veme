import React, { Component } from 'react'
import { connect,getAccounts,getChainId,initState,ethereum } from './metamask';
import {vemeabi} from '../abi/vemeabi'
import {vemeaddr} from '../contracts'
import styled from "styled-components";
import Collapse from "@kunukn/react-collapse";
import Web3 from 'web3'
import StyledLink from './StyledLink'
import Logo from '../images/Logo_White_Green.png';

class ApplyLicense extends Component {

constructor(props) {
    super(props)
     this.state = {
        isOpen4: false,
        metadata : '',
        web3 :new Web3(window.ethereum),
        contractInstance :null
       
    }
    
    this.fetchMetaData = this.fetchMetaData.bind(this);
    this.apply = this.apply.bind(this);
    this.toggle = this.toggle.bind(this);
}
componentDidMount(){
  connect();
  getAccounts();
  getChainId();
  const contractInstance = new this.state.web3.eth.Contract(vemeabi,vemeaddr)
  this.setState({contractInstance})
 }

async  apply(event)
{
 event.preventDefault()
 var id = this.refs.id.value;
 var transhash;
 await this.state.contractInstance.methods.addLicense(id.toString()).send({from:initState.accounts.toString()}).on('transactionHash', (hash)=>{
  transhash = hash;
  this.toggle(3)
  var pop = document.getElementById("transdata")
 pop.href = 'https://mumbai.polygonscan.com/tx/'+transhash;
 pop.target = "blank";
 })
}

async fetchMetaData(event){
  event.preventDefault()
 var id = this.refs.mid.value;
 var totalSupply = await this.state.contractInstance.methods.totalSupply(id).call();
 var creator = await this.state.contractInstance.methods.creatorList(id).call();
 var remixer = await this.state.contractInstance.methods.getRemixerList(id).call();
 var hash = await this.state.contractInstance.methods.getIpfsHashofId(id).call();
 
 let metadata =  {
   "image":"https://ipfs.io/ipfs/"+hash,
   "creator":
       {
           "address":creator ,
            "date":Math.round(new Date().getTime()/1000),
            "fingerprinthash" :"0x91f4fc608dfbd5bf5a18256219fe689a467e824c16aca24868321492c52a5eae "
       }
    
  
   }
var p = document.getElementById('pmetadata')

var object = JSON.parse(JSON.stringify(metadata));
p.innerText = "Metadata" +  "\nImage URL: "+ object.image+"\nCreator: "+ object.creator.address+ "\nDate: "+ object.creator.date +"\nFingerPrintHash: " + object.creator.fingerprinthash +"\n";
;
console.log(object);
if(totalSupply > 1){
   metadata = { ...metadata,remixer:{}}
  for(let i =0 ;i<totalSupply - 1;i++){
    var num = i;
    var val = 
    
      {
    "address":remixer[i],
    "date" :Math.round(new Date().getTime()/1000),
    "url" :"ipfs/io/Qmerwsy6wjdk98dnoa32vg"
    };
    metadata.remixer[num] = val;
  }
  var remixObject = JSON.parse(JSON.stringify(metadata.remixer));


let text = "";
for (let x in remixObject) {
 
    text = text + x +" :" + "\nRemixer :"+ remixObject[x].address +"\nDate :"+ remixObject[x].date+"\nLicense Url :"+remixObject[x].url +"\n";
  
}
console.log(text);
  p.innerText +=  text ;

}
 
}
  async toggle(index) {
    let collapse = "isOpen" + index;
    this.setState((prevState) => ({ [collapse]: !prevState[collapse] }));
  };
  closePopUp = () => {
    this.setState({ isOpen4: false });
  };
 render() 
   
    {
      return (
        <MainSection>
        <div className="logo">
         <img src={Logo} alt="" />
        </div>
        <div className="menu">
        <StyledLink to="/createnft">Create NFT</StyledLink>
            </div>
        <div className="main-inner">
          <h2>Apply For License</h2>
          <form onSubmit={this.apply} >
            <input type='text' ref = "id" />
            <input type='submit' className="sb-btn" />
          </form>
         
          <form onSubmit={this.fetchMetaData}>
            <input type ="text" ref = "mid" />
            <button id = "metadata" type = "submit" onClick={() => this.toggle(4)}>View Metadata</button>
          </form>
        
        </div>
          
        <Collapse
              isOpen={this.state.isOpen4}
              className={
                "app__collapse " + (this.state.isOpen4 ? "collapse-active" : "")
              }
            >
          <BlackWrap>
            <WhiteBX01>
              <CloseBTN onClick={() => {this.toggle(4);}}>
                x
              </CloseBTN>
              <p id = "pmetadata"></p>
            </WhiteBX01>
          </BlackWrap>
        </Collapse>
        <Collapse
              isOpen={this.state.isOpen3}
              className={
                "app__collapse " + (this.state.isOpen3 ? "collapse-active" : "")
              }
            >
            <BlackWrap>
                <WhiteBX01>
                  <CloseBTN onClick={() => {this.toggle(3);}}>
                    x
                  </CloseBTN>
                  <Tsblock>
                    <div class="loader"></div>
                    <h2>Transaction Successful</h2>
                    <a id = "transdata"href="#">Check on polygonscan</a>
                  </Tsblock>
                </WhiteBX01>
              </BlackWrap>
          </Collapse>
      </MainSection> 

  )
}

}
const Tsblock = styled.div`
h2{
 margin-bottom:30px;
}  
a{
  display:block;
  color:#3beac4;
}
.loader {
border: 5px dashed #f3f3f3; /* Light grey */
border-top: 5px dashed #3beac4; /* Blue */
border-radius: 50%;
width: 50px;
height: 50px;
animation: spin 2s linear infinite;
margin:0 auto 30px;
}

@keyframes spin {
0% { transform: rotate(0deg); }
100% { transform: rotate(360deg); }
}
`;
const BlackWrap = styled.div`
position: fixed;
left: 0;
right: 0;
top: 0;
bottom: 0;
background-color: rgba(0, 0, 0, 0.6);
z-index: 101;
backdrop-filter: blur(2px);
display:flex;
justify-content: center;
align-items: center;

`;
const WhiteBX01 = styled.div`
width: 100%;
position: relative;
max-width: 400px;
margin: 0 15px;
min-height: 300px;
padding: 50px;
background-color: #fff;
border-radius: 30px;
display:flex;
justify-content: center;
align-items: center;
p{
word-break: break-all;
}
`;

const CloseBTN = styled.button`
width: 30px;
height: 30px;
position: absolute;
right: 20px;
top: 27px;
padding: 0;
margin: 0px;
border:none;
background-color:#3beac4;
color:#fff;
border-radius:5px;
font-size:16px;
cursor:pointer;
`;

const CustAlert = styled.div`
position:absolute;
top:30px;
right:30px;
background-color:#fff;
padding:20px;
border-radius:10px;
max-width:400px;
width:100%;
p{
margin:0px;
text-align:left;
word-break:break-all;
padding-right:15px;
}
.close
{
position:absolute;
top:8px;
right:8px;
width:20px;
height:20px;
border-radius:5px;
background-color:#3beac4;
color:#fff;
line-height:15px;
cursor:pointer;
}
`;

const MainSection = styled.div`
background-color:#7c59f9;
position:relative;
height:100vh;
display:flex;
align-items:center;
justify-content:center;
.collapse-css-transition { transition: all 280ms cubic-bezier(0.4, 0, 0.2, 1); }
.app__collapse{ visibility:hidden; opacity:0; height:0px; }
.app__collapse.collapse-active{ visibility:visible; opacity:1; height:auto; }
.logo
{
  position:absolute;
  top:30px;
  left:30px;
}
.menu
{
  position:absolute;
  top:30px;
  right:30px;
  a{
    color:#fff;
    font-size:15px;
    text-decoration:none;
    :hover
    {
      color:#eee;
    }
  }
}
.main-inner{
  background-color:#fff;
  border-radius:30px;
  padding:30px;
  max-width:400px;
  width:100%;
  h2{
    margin:0px 0px 40px;
    font-size:32px;
    position:relative;
    :after
    {
      content:'';
      position:absolute;
      bottom:-10px;
      left:calc(50% - 25px);
      width:50px;
      height:2px;
      background-color:#000;
    }
  }
  form{
    position:relative;
    input{
      width:100%;
      border:1px solid #ccc;
      padding:10px;
      font-size:16px;
      color:#000;
      border-radius:10px;
      box-sizing: border-box;
      margin-bottom:20px;
      height:45px;
      :focus
      {
        outline:none;
        box-shadow:none;
      }
      &.sb-btn
      {
        position:absolute;
        top:0px;
        right:0px;
        width:auto;
        background-color:#3beac4;
        padding:14px 20px;
        color:#fff;
        border:none;
        border-top-left-radius:0px;
        border-bottom-left-radius:0px;
        line-height:15px;
        margin:0px;
        cursor:pointer;
        font-size:15px;
        font-weight:600;
        letter-spacing:-0.2px;
        :hover
        {
          background-color:#13d0a7;
        }
      }
    }
    button{
        position:absolute;
        top:0px;
        right:0px;
        width:auto;
        background-color:#3beac4;
        padding:15px;
        border-radius:10px;
        border-top-left-radius:0px;
        border-bottom-left-radius:0px;
        color:#fff;
        border:none;
        line-height:15px;
        margin:0px;
        cursor:pointer;
        font-size:15px;
        font-weight:600;
        letter-spacing:-0.2px;
        :hover
        {
          background-color:#13d0a7;
        }
    }
  }
}
`;
export  default ApplyLicense
 

