import React from 'react'
import { Link } from 'react-router-dom';
import styled from 'styled-components';


const StyledLink = styled(Link)`
position:absolute;
top:30px;
right:30px;
color:#fff;
font-size:15px;
text-decoration:none;
   &:hover{
       
          color:#eee;
        
    }
`;

export default (props) => <StyledLink {...props} />;