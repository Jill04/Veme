import logo from './logo.svg';
import './App.css';
import ApplyLicense from './components/ApplyLicense';
import IpfsStorage from './components/IpfsStorage';
import StyledLink from './components/StyledLink';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
function App() {
  return (
    
     
    
       
     
    
     <Router>
          
              <div className="App">
                <Switch>
                  <Route exact path="/" component ={IpfsStorage} />
                  <Route  path="/createnft" component ={IpfsStorage}/>
                  <Route   path="/applylicense" component ={ApplyLicense}/>
                </Switch>
               </div>
            </Router>
          
   
     
     
    
    
  );
  
}

export default App;
